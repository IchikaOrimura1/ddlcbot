const { CommandoClient } = require('discord.js-commando');
const config = require("./config.json");
const path = require('path');

const client = new CommandoClient({
    commandPrefix: '<',
    unknownCommandResponse: false,
    owner: '',
    disableEveryone: false
});

client.registry
    .registerDefaultTypes()
    .registerGroups([
        ['group1', 'Our First Command Group']
    ])
    .registerDefaultGroups()
    .registerDefaultCommands()
    .registerCommandsIn(path.join(__dirname, 'commands'));

client.on('ready', () => {
    console.log('Logged in!');
    client.user.setActivity('game');
});

client.login(config.token);